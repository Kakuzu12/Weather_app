//
//  NetworkProperties.swift
//  Weather_app
//
//  Created by Егор on 03.08.2020.
//  Copyright © 2020 Егор. All rights reserved.
//

import UIKit

struct NetworkProperties {
    static let API_KEY = "5aa8d384afe4769c566762d5e85249ba"
}
